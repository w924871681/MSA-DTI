MSA-DTI manuscript and supplementary material for author review

Compile main.tex and supplementary.tex separately with pdfLaTeX until
cross-references settle (usually three passes in a clean directory).
To switch documents in Overleaf, change the main document in project settings.

To reproduce the numerical assets, run the following from the project root
with Python 3, NumPy, pandas and Matplotlib. The bundled Tinos fonts are used
by the original manuscript plotters. No training or network access is needed.

    python -B plotting/build_results.py
    python -B plotting/plot_figures.py
    python -B plotting/plot_budget_figure.py
    python -B plotting/plot_msa_vs_fixed_pt.py
    python -B plotting/plot_azure_budget_paths.py
    python -B plotting/build_supplement.py

The first script derives the quantitative tables (3--6) and plot inputs.
Tables 1--2 describe the actual implementation and design. The four plot
scripts regenerate Figures 5--7, Figure 8, Figure 9 and Figure 10 in order.
Figures 1--4 are fixed illustrations.
Text in Figures 5--10 and S1--S3 uses Tinos at its final printed size (9 pt),
with smaller mathematical indices. Panel labels sit beneath each panel row. Regeneration also writes local previews.
The last script builds the supplementary tables and Figures S1--S3.

Data groupings
  * Bitbrains. Read deployment.csv for the fixed-backbone deployment study.
    All fixed PT-FT selections use A39. The tight PT-FT records in
    task_results.csv instead belong to a separate budget-aware PT-FT control.
    These tight-control accuracies and its additional timing are excluded
    from the fixed-backbone comparison. The medium rows coincide.
  * bitbrains_policy.csv contains the reference-only, direct and calibrated
    rules on the same bank. The lower-case method identifiers here differ
    from the display names of the seven external baselines.
  * Azure. frozen19.csv and budget_paths_19.csv contain the current MSA
    experiment. Only the seven baselines from baseline_archive.csv enter the
    new comparisons. For three search baselines the archived shortlist was
    formed from the full pool, which is admissible at the loose budget.
    medium_search_verified.csv and tight_search_verified.csv supply 360
    search records per budget. The three searches formed their shortlists
    within the active limits. resources.json supplies the resource profiles.
    Table 6 reports errors in units of 10^-3 with three decimal places.
    It groups the four tasks within each of 30 subscriptions. “Over budget” marks a method with zero deployable outputs at that budget.
  * no_preselection.csv contains the paired 48-candidate ablation. The other
    two main controls use the archived full-bank selections and the direct
    validation choices in bitbrains_policy.csv.
  * evidence.json records archive fingerprints and matched input checks.
    roles.json lists the six disjoint Bitbrains groups. Model descriptions,
    screening counts, reference rankings and frozen calibration decisions
    accompany the numerical records. The full training archive is separate.

  * data/supplement contains verified decisions for each task and condition,
    source-bank counts, screening evidence, latency summaries, the timing
    device configuration, and target-stage measurements.

The public companion repository contains the training, verification and plotting code.
https://github.com/w924871681/MSA-DTI
Run python code/reproduce.py scores --bitbrains PATH_TO_FASTSTORAGE_ZIP
and python code/reproduce.py supplement --bitbrains PATH_TO_FASTSTORAGE_ZIP from the repository root.
These commands retrieve checksummed evidence and rebuild the inputs from public datasets.
